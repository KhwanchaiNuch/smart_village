import { Component } from '@angular/core';
@Component({
  selector: 'app-master-area',
  templateUrl: './master-area.component.html',
  styleUrls: ['./master-area.component.scss']
})
export class MasterAreaComponent {
  tab = 'province';
}
