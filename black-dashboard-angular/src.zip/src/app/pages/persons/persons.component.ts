import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { PersonDialogComponent } from './person-dialog.component';

export interface PersonRow {
  person_id: number;
  citizen_id: string;
  full_name: string;
  sex: 'ชาย'|'หญิง'|'อื่นๆ';
  birth_date: string;
  occupation: string;
  is_sick: boolean;
  is_bedridden: boolean;
  has_house_reg: boolean;
  household_house_no: string;
  village_name: string;
  tambon: string;
  amphur: string;
  province: string;
}

@Component({
  selector: 'app-persons',
  templateUrl: './persons.component.html',
  styleUrls: ['./persons.component.scss'],
})
export class PersonsComponent {
  displayedColumns = ['citizen_id','full_name','sex','occupation','is_sick','is_bedridden','has_house_reg','household_house_no','village_name','actions'];

  rows: PersonRow[] = [
    {
      person_id: 1,
      citizen_id: '1103700XXXXXX',
      full_name: 'นายสมชาย ใจดี',
      sex: 'ชาย',
      birth_date: '1987-03-10',
      occupation: 'เกษตรกร',
      is_sick: false,
      is_bedridden: false,
      has_house_reg: true,
      household_house_no: '210/3',
      village_name: 'บ้านท่าข้าม',
      tambon: 'ท่าข้าม',
      amphur: 'ชนแดน',
      province: 'เพชรบูรณ์',
    },
    {
      person_id: 2,
      citizen_id: '1103700YYYYYY',
      full_name: 'นางสาวสุนิสา',
      sex: 'หญิง',
      birth_date: '1993-07-22',
      occupation: 'ค้าขาย',
      is_sick: true,
      is_bedridden: false,
      has_house_reg: true,
      household_house_no: '88',
      village_name: 'บ้านหนองปลาไหล',
      tambon: 'ท่าข้าม',
      amphur: 'ชนแดน',
      province: 'เพชรบูรณ์',
    },
  ];

  filterText = '';

  get filteredRows(): PersonRow[] {
    const t = this.filterText.trim().toLowerCase();
    if (!t) return this.rows;
    return this.rows.filter((r) =>
      [r.citizen_id, r.full_name, r.occupation, r.household_house_no, r.village_name, r.tambon, r.amphur, r.province]
        .some((v) => (v ?? '').toString().toLowerCase().includes(t))
    );
  }

  constructor(private dialog: MatDialog) {}

  add() {
    const ref = this.dialog.open(PersonDialogComponent, { width: '860px', data: { mode: 'add' } });
    ref.afterClosed().subscribe((val?: Partial<PersonRow>) => {
      if (!val) return;
      const nextId = Math.max(...this.rows.map((x) => x.person_id), 0) + 1;
      this.rows = [...this.rows, { ...(val as any), person_id: nextId }];
    });
  }

  edit(row: PersonRow) {
    const ref = this.dialog.open(PersonDialogComponent, { width: '860px', data: { mode: 'edit', value: row } });
    ref.afterClosed().subscribe((val?: Partial<PersonRow>) => {
      if (!val) return;
      this.rows = this.rows.map((r) => (r.person_id === row.person_id ? { ...row, ...(val as any) } : r));
    });
  }

  remove(row: PersonRow) {
    if (!confirm(`ลบข้อมูลประชากร: ${row.full_name} ?`)) return;
    this.rows = this.rows.filter((r) => r.person_id !== row.person_id);
  }
}
