import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { PersonRow } from './persons.component';

export interface PersonDialogData {
  mode: 'add'|'edit';
  value?: PersonRow;
}

@Component({
  selector: 'sv-person-dialog',
  templateUrl: './person-dialog.component.html',
  styleUrls: ['./person-dialog.component.scss']
})
export class PersonDialogComponent {
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private ref: MatDialogRef<PersonDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: PersonDialogData
  ) {
    const v = data.value;
    this.form = this.fb.group({
      citizen_id: [v?.citizen_id ?? '', [Validators.required, Validators.minLength(13)]],
      full_name: [v?.full_name ?? '', Validators.required],
      sex: [v?.sex ?? 'ชาย', Validators.required],
      birth_date: [v?.birth_date ?? '', Validators.required],
      occupation: [v?.occupation ?? ''],
      is_sick: [v?.is_sick ?? false],
      is_bedridden: [v?.is_bedridden ?? false],
      in_house_register: [v?.in_house_register ?? true],
      household_id: [v?.household_id ?? 1, Validators.required],
    });
  }

  save() {
    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }
    this.ref.close(this.form.value);
  }

  close() { this.ref.close(); }
}
