import { Component } from '@angular/core';

@Component({
  selector: 'app-profile-settings',
  templateUrl: './profile-settings.component.html',
  styleUrls: ['./profile-settings.component.scss']
})
export class ProfileSettingsComponent {

  profile = {
    fullName: 'ผู้ใช้งานตัวอย่าง',
    username: 'demo',
    roleLevel: 'VILLAGE',
    scopeName: 'หมู่ 1 บ้านตัวอย่าง'
  };

  pwd = { current: '', next: '', confirm: '' };

  saveProfile(): void {
    alert('บันทึกโปรไฟล์ (ตัวอย่าง UI) — จะเชื่อม API ภายหลัง');
  }

  changePassword(): void {
    if (!this.pwd.next || this.pwd.next !== this.pwd.confirm) {
      alert('รหัสผ่านใหม่ไม่ตรงกัน');
      return;
    }
    alert('เปลี่ยนรหัสผ่าน (ตัวอย่าง UI) — จะเชื่อม API ภายหลัง');
    this.pwd = { current: '', next: '', confirm: '' };
  }
}
