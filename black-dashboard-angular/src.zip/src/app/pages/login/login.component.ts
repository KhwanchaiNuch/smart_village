import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent {

  model = { username: '', password: '' };
  isSubmitting = false;
  errorMsg = '';

  constructor(private router: Router) {}

  submit(): void {
    this.errorMsg = '';
    if (!this.model.username || !this.model.password) {
      this.errorMsg = 'กรุณากรอก Username และ Password';
      return;
    }

    // UI only (mock). Later we will call Spring Boot /api/auth/login and store JWT.
    this.isSubmitting = true;
    setTimeout(() => {
      this.isSubmitting = false;
      // pretend success
      localStorage.setItem('sv_mock_login', '1');
      this.router.navigateByUrl('/dashboard');
    }, 500);
  }
}
