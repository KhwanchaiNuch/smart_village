import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { HouseholdDialogComponent } from './household-dialog.component';

export interface HouseholdRow {
  household_id: number;
  house_no: string;
  moo: string;
  village_name: string;
  tambon: string;
  amphur: string;
  province: string;
  head_name: string;
  members: number;
}

@Component({
  selector: 'app-households',
  templateUrl: './households.component.html',
  styleUrls: ['./households.component.scss'],
})
export class HouseholdsComponent {
  displayedColumns = [
    'house_no',
    'village_name',
    'moo',
    'tambon',
    'amphur',
    'province',
    'head_name',
    'members',
    'actions',
  ];

  rows: HouseholdRow[] = [
    {
      household_id: 1,
      house_no: '210/3',
      moo: '3',
      village_name: 'บ้านท่าข้าม',
      tambon: 'ท่าข้าม',
      amphur: 'ชนแดน',
      province: 'เพชรบูรณ์',
      head_name: 'นายสมชาย ใจดี',
      members: 4,
    },
    {
      household_id: 2,
      house_no: '88',
      moo: '1',
      village_name: 'บ้านหนองปลาไหล',
      tambon: 'ท่าข้าม',
      amphur: 'ชนแดน',
      province: 'เพชรบูรณ์',
      head_name: 'นางสาวสุนิสา',
      members: 2,
    },
  ];

  filterText = '';

  get filteredRows(): HouseholdRow[] {
    const t = this.filterText.trim().toLowerCase();
    if (!t) return this.rows;
    return this.rows.filter((r) =>
      [r.house_no, r.village_name, r.moo, r.tambon, r.amphur, r.province, r.head_name].some((v) =>
        (v ?? '').toString().toLowerCase().includes(t)
      )
    );
  }

  constructor(private dialog: MatDialog) {}

  add() {
    const ref = this.dialog.open(HouseholdDialogComponent, {
      width: '720px',
      data: { mode: 'add' },
    });

    ref.afterClosed().subscribe((val?: Partial<HouseholdRow>) => {
      if (!val) return;
      const nextId = Math.max(...this.rows.map((x) => x.household_id), 0) + 1;
      this.rows = [...this.rows, { ...(val as any), household_id: nextId }];
    });
  }

  edit(row: HouseholdRow) {
    const ref = this.dialog.open(HouseholdDialogComponent, {
      width: '720px',
      data: { mode: 'edit', value: row },
    });

    ref.afterClosed().subscribe((val?: Partial<HouseholdRow>) => {
      if (!val) return;
      this.rows = this.rows.map((r) => (r.household_id === row.household_id ? { ...row, ...(val as any) } : r));
    });
  }

  remove(row: HouseholdRow) {
    if (!confirm(`ลบครัวเรือน บ้านเลขที่ ${row.house_no} ?`)) return;
    this.rows = this.rows.filter((r) => r.household_id !== row.household_id);
  }
}
