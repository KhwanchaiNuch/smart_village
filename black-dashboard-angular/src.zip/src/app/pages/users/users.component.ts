import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { UserDialogComponent } from './user-dialog.component';

export interface UserRow {
  user_id: number;
  username: string;
  full_name: string;
  role_level: string;
  scope_id: number | null;
  is_active: boolean;
}

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.scss']
})
export class UsersComponent {
  q = '';

  columns: string[] = ['user_id','username','full_name','role_level','scope_id','is_active','actions'];

  rows: UserRow[] = [
    { user_id: 1, username: 'admin', full_name: 'ผู้ดูแลระบบ', role_level: 'ADMIN', scope_id: null, is_active: true },
    { user_id: 2, username: 'prov', full_name: 'ผู้ใช้ระดับจังหวัด', role_level: 'PROVINCE', scope_id: 10, is_active: true },
    { user_id: 3, username: 'amp', full_name: 'ผู้ใช้ระดับอำเภอ', role_level: 'AMPHUR', scope_id: 1001, is_active: true },
    { user_id: 4, username: 'tam', full_name: 'ผู้ใช้ระดับตำบล', role_level: 'TAMBON', scope_id: 100101, is_active: true },
    { user_id: 5, username: 'vil', full_name: 'ผู้ใช้ระดับหมู่บ้าน', role_level: 'VILLAGE', scope_id: 10010101, is_active: true }
  ];

  constructor(private dialog: MatDialog) {}

  get filtered(): UserRow[] {
    const q = this.q.trim().toLowerCase();
    if (!q) return this.rows;
    return this.rows.filter(r =>
      `${r.user_id} ${r.username} ${r.full_name} ${r.role_level} ${r.scope_id ?? ''}`
        .toLowerCase()
        .includes(q)
    );
  }

  add(): void {
    const ref = this.dialog.open(UserDialogComponent, { width: '860px', data: { mode: 'add' } });
    ref.afterClosed().subscribe((value?: UserRow) => {
      if (!value) return;
      const nextId = Math.max(...this.rows.map(x => x.user_id), 0) + 1;
      this.rows = [{ ...value, user_id: nextId }, ...this.rows];
    });
  }

  edit(row: UserRow): void {
    const ref = this.dialog.open(UserDialogComponent, { width: '860px', data: { mode: 'edit', value: row } });
    ref.afterClosed().subscribe((value?: UserRow) => {
      if (!value) return;
      this.rows = this.rows.map(x => (x.user_id === row.user_id ? { ...row, ...value } : x));
    });
  }

  remove(row: UserRow): void {
    if (!confirm(`ลบผู้ใช้ ${row.username} ?`)) return;
    this.rows = this.rows.filter(x => x.user_id !== row.user_id);
  }
}
