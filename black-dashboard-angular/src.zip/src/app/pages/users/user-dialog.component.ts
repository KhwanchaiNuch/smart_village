import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { UserRow } from './users.component';

export interface UserDialogData {
  mode: 'add'|'edit';
  value?: UserRow;
}

@Component({
  selector: 'sv-user-dialog',
  templateUrl: './user-dialog.component.html',
  styleUrls: ['./user-dialog.component.scss']
})
export class UserDialogComponent {
  form: FormGroup;
  roles = [
    { value: 'ADMIN', text: 'ADMIN (เห็นทุกพื้นที่)' },
    { value: 'PROV', text: 'PROV (จังหวัด)' },
    { value: 'AMP', text: 'AMP (อำเภอ)' },
    { value: 'TAM', text: 'TAM (ตำบล)' },
    { value: 'VIL', text: 'VIL (หมู่บ้าน)' }
  ];

  constructor(
    private fb: FormBuilder,
    private ref: MatDialogRef<UserDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: UserDialogData
  ) {
    const v = data.value;
    this.form = this.fb.group({
      username: [v?.username ?? '', [Validators.required, Validators.minLength(3)]],
      full_name: [v?.full_name ?? '', Validators.required],
      role_level: [v?.role_level ?? 'ADMIN', Validators.required],
      scope_id: [v?.scope_id ?? null],
      is_active: [v?.is_active ?? true]
    });

    // สร้าง/แก้ไข: ถ้า role = ADMIN ให้ scope_id = null
    this.form.get('role_level')?.valueChanges.subscribe((role: string) => {
      if (role === 'ADMIN') {
        this.form.patchValue({ scope_id: null }, { emitEvent: false });
      }
    });
  }

  save() {
    if (this.form.invalid) return;
    const payload: UserRow = {
      user_id: this.data.value?.user_id ?? 0,
      ...this.form.value
    };
    this.ref.close(payload);
  }

  cancel() {
    this.ref.close(null);
  }
}
