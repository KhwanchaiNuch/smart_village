import { Component } from '@angular/core';
@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent {
  stats = [
    {label:'ครัวเรือน', value: 128},
    {label:'ประชากร', value: 456},
    {label:'ผู้สูงอายุ', value: 78},
    {label:'ติดเตียง', value: 5}
  ];
}
