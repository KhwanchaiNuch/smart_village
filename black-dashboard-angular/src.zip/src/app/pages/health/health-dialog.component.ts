import { Component, Inject } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';
import { HealthRow } from './health.component';

export interface HealthDialogData {
  mode: 'add'|'edit';
  value?: HealthRow;
}

@Component({
  selector: 'sv-health-dialog',
  templateUrl: './health-dialog.component.html',
  styleUrls: ['./health-dialog.component.scss']
})
export class HealthDialogComponent {
  form: FormGroup;

  constructor(
    private fb: FormBuilder,
    private ref: MatDialogRef<HealthDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: HealthDialogData
  ) {
    const v = data.value;
    this.form = this.fb.group({
      person_name: [v?.person_name ?? '', Validators.required],
      visit_date: [v?.visit_date ?? '', Validators.required],
      chronic: [v?.chronic ?? ''],
      is_bedridden: [v?.is_bedridden ?? false],
      note: [v?.note ?? '']
    });
  }

  submit() {
    if (this.form.invalid) return;
    this.ref.close(this.form.value);
  }
}
