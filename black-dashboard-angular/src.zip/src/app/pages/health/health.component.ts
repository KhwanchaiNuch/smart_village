import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { HealthDialogComponent } from './health-dialog.component';

export interface HealthRow {
  visit_id: number;
  person_name: string;
  visit_date: string;
  chronic: string;
  is_bedridden: boolean;
  note: string;
}

@Component({
  selector: 'app-health',
  templateUrl: './health.component.html',
  styleUrls: ['./health.component.scss']
})
export class HealthComponent {
  q = '';
  displayedColumns = ['visit_date','person_name','chronic','is_bedridden','note','actions'];

  rows: HealthRow[] = [
    { visit_id: 1, person_name: 'นายสมชาย ใจดี', visit_date: '05/01/2569', chronic: 'เบาหวาน', is_bedridden: false, note: 'ให้คำแนะนำโภชนาการ' },
    { visit_id: 2, person_name: 'นางสาวสุดา พรมดี', visit_date: '06/01/2569', chronic: '-', is_bedridden: false, note: 'ติดตามความดัน' },
  ];

  constructor(private dialog: MatDialog) {}

  get filteredRows(): HealthRow[] {
    const s = this.q.trim().toLowerCase();
    if (!s) return this.rows;
    return this.rows.filter(r =>
      [r.person_name, r.visit_date, r.chronic, r.note].some(v => (v ?? '').toString().toLowerCase().includes(s))
    );
  }

  add() {
    const ref = this.dialog.open(HealthDialogComponent, { width: '760px', data: { mode: 'add' } });
    ref.afterClosed().subscribe((value?: HealthRow) => {
      if (!value) return;
      const nextId = Math.max(...this.rows.map(r => r.visit_id), 0) + 1;
      this.rows = [{ ...value, visit_id: nextId }, ...this.rows];
    });
  }

  edit(row: HealthRow) {
    const ref = this.dialog.open(HealthDialogComponent, { width: '760px', data: { mode: 'edit', value: row } });
    ref.afterClosed().subscribe((value?: HealthRow) => {
      if (!value) return;
      this.rows = this.rows.map(r => (r.visit_id === row.visit_id ? { ...r, ...value } : r));
    });
  }

  remove(row: HealthRow) {
    if (!confirm(`ลบข้อมูลเยี่ยมบ้านของ "${row.person_name}" ?`)) return;
    this.rows = this.rows.filter(r => r.visit_id !== row.visit_id);
  }
}
