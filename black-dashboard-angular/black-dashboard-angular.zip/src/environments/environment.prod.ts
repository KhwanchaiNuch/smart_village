export const environment = {
  production: true,
  // ปรับ URL ให้ตรงกับ Production ของคุณ
  apiBaseUrl: 'http://localhost:8082/smart_village/api'
};
